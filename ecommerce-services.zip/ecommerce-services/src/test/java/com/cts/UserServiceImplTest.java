package com.cts;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;

import com.cts.response.Response;
import com.cts.service.impl.UserServiceImpl;

@SpringBootTest
public class UserServiceImplTest {

	@Autowired
	private UserServiceImpl userService;

	@Test
	public void testGetUserDetails_ValidUserId() {
		// Arrange
		Integer userId = 1;

		// Act
		Response response = userService.getUserDetails(userId);

		// Assert
		assertEquals(HttpStatus.OK, response.getStatus()); //assert that two values are equal. It compares the expected value with the actual value and throws an assertion error if they are not equal.
        assertNotNull(response.getData()); //It verifies that the specified object is not null and throws an assertion error if it is.
	}

	@Test
	public void testGetUserDetails_InValidUserId() {
		// Arrange
		Integer nonExistingUserId = 9999;
		Response response = userService.getUserDetails(nonExistingUserId);
		assertNull(response.getData());
	}

}
