package com.cts;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.test.context.junit4.SpringRunner;

import com.cts.model.UserDetails;
import com.cts.response.Response;
import com.cts.service.impl.UserServiceImpl;

@RunWith(SpringRunner.class)
@SpringBootTest
class EcommerceServicesApplicationTests {

	@Test
	void contextLoads() {
	}


}
