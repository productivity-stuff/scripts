package com.cts.testcases;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;

import com.cts.exception.UserDetailsNotFoundException;
import com.cts.response.Response;
import com.cts.service.impl.UserServiceImpl;

//@SpringBootTest
public class UserServiceImplTest  {

    @Autowired
    private UserServiceImpl userService;

    @Test
    public void testGetUserDetails_ValidUserId() {
        // Arrange
        Integer userId = 1;

        // Act
        Response response = userService.getUserDetails(userId);

        // Assert
        assertEquals(HttpStatus.OK, response.getStatus());
        assertNotNull(response.getData());
        // Add more assertions as needed
    }

    @Test
    public void testGetUserDetails_UserDetailsNotFoundException() {
        // Arrange
        Integer nonExistingUserId = 9999;

        // Act and Assert
        assertThrows(UserDetailsNotFoundException.class, () -> userService.getUserDetails(nonExistingUserId));
    }

	

    // Add more test methods to cover other scenarios

}
